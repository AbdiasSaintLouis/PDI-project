# Music Note Extraction 
### Using Digital Signal Processing
Watch demo video here: https://youtu.be/m7FuJaxWD3A
